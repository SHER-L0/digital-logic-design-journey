module adder(
    input  [3:0] A,
    input  [3:0] B,
    input  addsub,       
    output [3:0] F,
    output cf,
    output zero,
    output of
);
    wire [3:0] B_mod;    
    wire [4:0] sum;      

    assign B_mod = B ^ {4{addsub}};    
    assign sum = A + B_mod + addsub;   

    assign F = sum[3:0];               
    assign cf = sum[4] ^ addsub;       
    assign zero = (F == 4'b0000);      
    assign of = (A[3] == B_mod[3]) && (F[3] != A[3]);  

endmodule
