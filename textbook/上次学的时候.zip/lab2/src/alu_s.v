module alu_s( input [3:0] A,
			  input [3:0] B,
			  input [2:0] ALUctr,
			  output reg [3:0] F,
			  output reg cf,
			  output reg zero,
			  output reg of
);

//add your code here
wire [3:0] op_adder;
wire [3:0] not_a = ~A;
wire [3:0] and_ab = A & B;
wire [3:0] or_ab = A | B;
wire [3:0] xor_ab = A ^ B;
wire [3:0] equal = (A === B);
wire signed [3:0] sa = A;
wire signed [3:0] sb = B;
wire [3:0] greater = (sa > sb);
adder adder_in_alu(
                    .A(A),
                    .B(B),
                    .addsub(ALUctr[0]),
                    .F(op_adder),
                    .cf(cf),
                    .zero(zero),
                    .of(of)
);
always@(*)begin
    case(ALUctr)
        3'b000:begin 
            F = op_adder;
        end
        3'b001:begin
            F = op_adder;
        end
        3'b010:begin
            F = not_a;
        end
        3'b011:begin
            F = and_ab;
        end
        3'b100:begin
            F = or_ab;
        end
        3'b101:begin
            F = xor_ab;
        end
        3'b110:begin
            F = greater;
        end
        3'b111:begin
            F = equal;
        end
    endcase
end
endmodule
module adder(
    input  [3:0] A,
    input  [3:0] B,
    input  addsub,       
    output [3:0] F,
    output cf,
    output zero,
    output of
);
    wire [3:0] B_mod;    
    wire [4:0] sum;      

    assign B_mod = B ^ {4{addsub}};    
    assign sum = A + B_mod + addsub;   

    assign F = sum[3:0];               
    assign cf = sum[4] ^ addsub;       
    assign zero = (F == 4'b0000);      
    assign of = (A[3] == B_mod[3]) && (F[3] != A[3]);  

endmodule