module clz(
 input [31:0] in,
 output [4:0] out,
 output zero
);
//add your code here
wire [15:0] sel1;
wire [7:0] sel2;
wire [3:0] sel3;
wire [1:0] sel4;
wire sel5;
assign sel1 = (| in[31:16]) ? in[31:16] : in[15:0];
assign sel2 = (| sel1[15:8]) ? sel1[15:8] : sel1[7:0];
assign sel3 = (| sel2[7:4]) ? sel2[7:4] : sel2 [3:0];
assign sel4 = (| sel3[3:2]) ? sel3[3:2] : sel3[1:0];
assign sel5 = sel4[1] ? sel4[1] : sel4[0];
assign out[4] = ~(| in[31:16]);
assign out[3] = ~(| sel1[15:8]);
assign out[2] = ~(| sel2[7:4]);
assign out[1] = ~(| sel3[3:2]);
assign out[0] = ~(| sel4[1]);
assign zero = ~(| in[31:0]);
endmodule