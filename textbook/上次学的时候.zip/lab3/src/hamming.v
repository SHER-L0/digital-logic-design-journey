module hamming(
	input  [6:0] code,
	output reg [6:0] correct,
	output [2:0] parity
	);

// add your code here
assign parity[0] = code[0] ^ code[2] ^ code[4] ^ code[6];
assign parity[1] = code[1] ^ code[2] ^ code[5] ^ code[6];
assign parity[2] = code[3] ^ code[4] ^ code[5] ^ code[6];
always @(*) begin
    if(parity === 0)
    correct = code;
    else begin
        correct = code;
        correct[parity - 1] = ~ correct[parity - 1];
    end
end
endmodule