module counter(
	input  clk,
	input  en,
	input  rst,
	input  [3:0] cnt_limit,
	output reg [3:0] Q,
	output reg rco
	);

// add your code here
always @(posedge clk) begin
    if(en)begin
        if(rst)begin
            Q <= 0;
            rco <= 0;
        end
        else begin
            if(Q + 1 === cnt_limit)begin
                Q <= 0;
                rco <= 1;
            end
            else begin
                Q <= Q + 1;
                rco <= 0;
            end
        end
    end
end
endmodule