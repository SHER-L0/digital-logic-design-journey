module shiftreg(input  [7:0]  din,
	input  clk,
	input  [2:0] func,
	input  lin,
	output reg [7:0] dout
	);
		
//add your code here
always @(posedge clk) begin
    case(func)
        3'b 000:begin
            dout <= 0;
        end
        3'b 001:begin
            dout <= din;
        end
        3'b 010:begin
            dout <= {1'b0,dout[7:1]};
        end
        3'b 011:begin
            dout <= {dout[6:0],1'b0};
        end
        3'b 100:begin
            dout <= {dout[7],dout[7:1]};
        end
        3'b 101:begin
            dout <= {lin,dout[7:1]};
        end
        3'b 110:begin
            dout <= {dout[0],dout[7:1]};
        end
        3'b 111:begin
            dout <= {dout[6:0],dout[7]};
        end
    endcase
end
endmodule