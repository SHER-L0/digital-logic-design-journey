module lfsr(input  [63:0]  seed,
	input  clk,
	input  load,
	output reg [63:0] dout
	);
//add your code here
    always @(posedge clk) begin
        case(load)
            1:begin
                dout <= seed;
            end
            0:begin
                dout[63] <= dout[4] ^ dout[3] ^ dout[1] ^ dout[0];
                dout[62:0] <= dout[63:1];
            end
        endcase
    end
endmodule