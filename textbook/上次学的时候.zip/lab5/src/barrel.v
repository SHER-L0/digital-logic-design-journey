module barrel(input [31:0] indata,
			  input [4:0] shamt,
			  input lr,
			  input al,
			  output reg [31:0] outdata);

//add your code here
always @(*) begin
    case (lr)
        0:begin
            case (al)
                0:begin
                    outdata <= indata >> shamt;
                end
                1:begin
                    outdata <= $signed(indata) >>> shamt;
                end
            endcase
        end 
        1:begin
            case (al)
                0:begin
                    outdata <= indata <<shamt;
                end
                1:begin
                    outdata <= indata <<<shamt;
                end
            endcase
        end
    endcase
end
endmodule