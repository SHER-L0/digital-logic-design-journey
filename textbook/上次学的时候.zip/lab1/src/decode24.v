module decode24(x,en,y);
input  [1:0] x; 
input en;
output reg[3:0] y;

    always @(x or en)
        begin
            if(en)
                begin
                    case(x)
                        2'd 0 : y = 4'b 0001;
                        2'd 1 : y = 4'b 0010;
                        2'd 2 : y = 4'b 0100;
                        2'd 3 : y = 4'b 1000;
                    endcase
                end 
            else y = 4'b 0000;
        end
endmodule