module encode42(x,en,y);
input[3:0] x;
input en;
output reg[1:0] y;

    always @(x or en)
        begin
            if(en)
                begin
                    case (x)
                        4'b 0001 : y = 2'b 00;
                        4'b 0010 : y = 2'b 01;
                        4'b 0100 : y = 2'b 10;
                        4'b 1000 : y = 2'b 11;
                        default : y = 2'b zz;
                    endcase
                end
            else y = 2'b zz; 
        end
endmodule