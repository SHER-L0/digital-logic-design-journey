module twobit_mux41(a,y,f);
input [7:0] a;
input [1:0] y;
output reg [1:0] f;
    always@(*)begin
        case(y)
            2'b 00: begin f = a[1:0]; end
            2'b 01: begin f = a[3:2]; end
            2'b 10: begin f = a[5:4]; end
            2'b 11: begin f = a[7:6]; end
            default: f = 2'b 00;
        endcase
    end
endmodule