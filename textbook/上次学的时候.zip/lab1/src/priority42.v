module priority42(x,en,y,valid);
input [3:0] x;
input en;
output reg [1:0] y;
output reg valid;
    always @(x or en) 
        begin
            if(!en) begin
                y = 2'b 0;
                valid = 2'b 0;
            end
            else
                begin
                    casex(x)
                        4'b 1???: begin y = 2'b 11; valid = 1'b 1; end
                        4'b 01??: begin y = 2'b 10; valid = 1'b 1; end
                        4'b 001?: begin y = 2'b 01; valid = 1'b 1; end
                        4'b 0001: begin y = 2'b 00; valid = 1'b 1; end
                            default: begin y = 2'b 00; valid = 1'b 0; end
                    endcase
                end
        end
endmodule