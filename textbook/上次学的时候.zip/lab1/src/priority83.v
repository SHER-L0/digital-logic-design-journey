module priority83(x,en,y,valid);
input [7:0] x;
input en;
output reg [2:0] y;
output reg valid;
    always@(*)begin
        if(!en)
        begin
            y = 3'b000;
            valid = 0;
        end
        else
        begin
            casez(x)
                8'b1??????? : begin 
                    valid = 1;
                    y = 7;
                end
                8'b01?????? : begin
                    valid = 1;
                    y = 6;
                end
                8'b001????? : begin
                    valid = 1;
                    y = 5;
                end
                8'b0001???? : begin
                    valid = 1;
                    y = 4;
                end
                8'b00001??? : begin
                    valid = 1;
                    y = 3;
                end
                8'b000001?? : begin
                    valid = 1;
                    y = 2;
                end
                8'b0000001? : begin
                    valid = 1;
                    y = 1;
                end
                8'b00000001 : begin
                    valid = 1;
                    y = 0;
                end
                default : begin
                    valid = 0;
                    y = 0;
                end
            endcase
        end 
    end
endmodule